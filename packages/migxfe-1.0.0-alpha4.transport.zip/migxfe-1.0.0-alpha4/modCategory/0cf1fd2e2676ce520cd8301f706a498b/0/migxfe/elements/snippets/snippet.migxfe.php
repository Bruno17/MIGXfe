<?php


return include ($modx->getOption('migxfe.core_path',null,$modx->getOption('core_path').'components/migxfe/elements/snippets/').'migxfe.php');